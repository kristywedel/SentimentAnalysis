import os
# Suppress TensorFlow warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import DistilBertTokenizer, TFDistilBertForSequenceClassification
import tensorflow as tf
import numpy as np
from typing import List
import uvicorn

# Initialize FastAPI app
app = FastAPI(
    title="Sentiment Analysis API",
    description="API for customer feedback sentiment analysis using DistilBERT",
    version="1.0.0"
)

# Define request model
class SentimentRequest(BaseModel):
    text: str

class BatchSentimentRequest(BaseModel):
    texts: List[str]

# Load tokenizer and model
try:
    tokenizer = DistilBertTokenizer.from_pretrained('sentiment_tokenizer')
    model = TFDistilBertForSequenceClassification.from_pretrained('sentiment_model')
except:
    raise RuntimeError("Model or tokenizer not found. Ensure the model is trained and saved correctly.")

def predict_sentiment(text: str) -> dict:
    # Tokenize text
    inputs = tokenizer(
        text,
        truncation=True,
        padding=True,
        max_length=128,
        return_tensors='tf'
    )
    
    # Make prediction
    outputs = model(inputs)
    probabilities = tf.nn.softmax(outputs.logits, axis=1)
    prediction = tf.argmax(probabilities, axis=1).numpy()[0]
    confidence = float(probabilities[0][prediction])
    
    # Map prediction to sentiment
    sentiment = "Negative" if prediction == 0 else "Positive/Neutral"
    
    return {
        "text": text,
        "sentiment": sentiment,
        "confidence": confidence,
        "probability": {
            "negative": float(probabilities[0][0]),
            "positive/neutral": float(probabilities[0][1])
        }
    }

@app.get("/")
def read_root():
    return {"message": "Welcome to the Sentiment Analysis API"}

@app.post("/predict")
def predict(request: SentimentRequest):
    try:
        return predict_sentiment(request.text)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/batch")
def predict_batch(request: BatchSentimentRequest):
    try:
        return [predict_sentiment(text) for text in request.texts]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)