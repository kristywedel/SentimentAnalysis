import requests
import json

def test_api():
    # API endpoint
    BASE_URL = "http://localhost:8000"
    
    # Test 1: Health check
    print("\n1. Testing health check endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/health")
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
    except Exception as e:
        print(f"Error: {str(e)}")

    # Test 2: Single prediction
    print("\n2. Testing single prediction endpoint...")
    test_cases = [
        "This product is amazing! I love it!",
        "Terrible service, would not recommend.",
        "It's okay, nothing special."
    ]
    
    for text in test_cases:
        try:
            response = requests.post(
                f"{BASE_URL}/predict",
                json={"text": text}
            )
            print(f"\nInput text: {text}")
            print(f"Status Code: {response.status_code}")
            print(f"Response: {json.dumps(response.json(), indent=2)}")
        except Exception as e:
            print(f"Error: {str(e)}")

    # Test 3: Batch prediction
    print("\n3. Testing batch prediction endpoint...")
    try:
        response = requests.post(
            f"{BASE_URL}/predict/batch",
            json={"texts": test_cases}
        )
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    print("Starting API tests...")
    test_api()
    print("\nAPI tests completed.") 