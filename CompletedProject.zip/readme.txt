To run the frontend:

Make sure your FastAPI backend (app.py) is running in one terminal:
python app.py

In another terminal, run the Streamlit frontend:
streamlit run frontend.py