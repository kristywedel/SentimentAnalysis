import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime

# Set page config
st.set_page_config(
    page_title="Sentiment Analysis Dashboard",
    layout="wide"
)

# Custom CSS
st.markdown("""
    <style>
    .main {
        padding: 2rem;
    }
    .stTextInput > div > div > input {
        padding: 0.5rem;
    }
    .sentiment-box {
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    </style>
    """, unsafe_allow_html=True)

# Title
st.title("📊 Sentiment Analysis Dashboard")

# Initialize session state for history
if 'history' not in st.session_state:
    st.session_state.history = []

# Input section
with st.container():
    st.subheader("Enter Text for Analysis")
    text_input = st.text_area("Type or paste text here:", height=100)
    
    if st.button("Analyze Sentiment"):
        if text_input:
            # Make API request
            try:
                response = requests.post(
                    "http://localhost:8000/predict",
                    json={"text": text_input}
                )
                
                if response.status_code == 200:
                    result = response.json()
                    
                    # Add timestamp and store in history
                    result['timestamp'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    st.session_state.history.append(result)
                    
                    # Display result
                    sentiment_color = "#28a745" if result['sentiment'] == "Positive/Neutral" else "#dc3545"
                    
                    st.markdown(f"""
                        <div class="sentiment-box" style="background-color: {sentiment_color}20;">
                            <h3 style="color: {sentiment_color};">Analysis Result</h3>
                            <p><strong>Sentiment:</strong> {result['sentiment']}</p>
                            <p><strong>Confidence:</strong> {result['confidence']:.2%}</p>
                        </div>
                    """, unsafe_allow_html=True)
                else:
                    st.error("Error analyzing text. Please try again.")
            except Exception as e:
                st.error(f"Error connecting to API: {str(e)}")
        else:
            st.warning("Please enter some text to analyze.")

# History and Analytics Section
if st.session_state.history:
    st.markdown("---")
    st.subheader("Analysis History and Analytics")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Convert history to DataFrame
        df = pd.DataFrame(st.session_state.history)
        
        # Sentiment Distribution Pie Chart
        fig_pie = px.pie(
            df,
            names='sentiment',
            title='Sentiment Distribution',
            color='sentiment',
            color_discrete_map={
                'Positive/Neutral': '#28a745',
                'Negative': '#dc3545'
            }
        )
        st.plotly_chart(fig_pie)
    
    with col2:
        # Confidence Distribution Box Plot
        fig_box = go.Figure()
        for sentiment in df['sentiment'].unique():
            sentiment_data = df[df['sentiment'] == sentiment]['confidence']
            fig_box.add_trace(go.Box(
                y=sentiment_data,
                name=sentiment,
                boxpoints='all',
                marker_color='#28a745' if sentiment == 'Positive/Neutral' else '#dc3545'
            ))
        fig_box.update_layout(
            title='Confidence Distribution by Sentiment',
            yaxis_title='Confidence Score',
            showlegend=False
        )
        st.plotly_chart(fig_box)
    
    # History Table
    st.subheader("Recent Analysis History")
    history_df = pd.DataFrame(st.session_state.history).sort_values(
        by='timestamp',
        ascending=False
    )
    st.dataframe(
        history_df[['timestamp', 'text', 'sentiment', 'confidence']],
        hide_index=True
    )
    
    # Clear History Button
    if st.button("Clear History"):
        st.session_state.history = []
        st.experimental_rerun()

else:
    st.info("No analysis history yet. Start by analyzing some text above!") 